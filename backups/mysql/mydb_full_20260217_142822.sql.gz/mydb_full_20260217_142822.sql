-- MySQL dump 10.13  Distrib 8.0.39, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fullName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `schoolNumber` int NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,'fdsfds','fdsafds',1231231,'dagaang.alfrancis@gmail.com','fhgfhghgfhgfhf'),(4,'Al Francis','Daga-ang',202233029,'dagaang.alfrancis13@gmail.com','@Pollywag123'),(5,'sdf','fff',123123123,'dagaangmarygrace@gmail.com','fdsfdsfdsfds'),(14,'fdsfdfffffs','fdsfdsf',111111,'dagaanfdsgffgfhgfhe@gmail.com','fdsferwrewrs');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `items` varchar(255) NOT NULL,
  `price` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,'Burger',40),(2,'Footlong',25),(3,'Fries',15),(4,'Shake',10.2),(5,'Siomai',15);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_records`
--

DROP TABLE IF EXISTS `medical_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medical_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `diagnosis` varchar(255) DEFAULT NULL,
  `doctor_notes` varchar(255) DEFAULT NULL,
  `patient_name` varchar(255) DEFAULT NULL,
  `prescription` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_records`
--

LOCK TABLES `medical_records` WRITE;
/*!40000 ALTER TABLE `medical_records` DISABLE KEYS */;
INSERT INTO `medical_records` VALUES (1,'Flu','Patient has mild fever and cough.','John Doe','Paracetamol 500mg'),(2,'Hypertension','Monitor blood pressure regularly.','Jane Smith','Amlodipine 5mg'),(3,'Diabetes','Maintain a low-sugar diet.','Michael Brown','Metformin 500mg'),(4,'Asthma','Use inhaler when needed.','Emily Johnson','Salbutamol Inhaler'),(5,'Migraine','Avoid bright lights and loud noise.','David Wilson','Ibuprofen 400mg'),(6,'Fractured Arm','Arm cast applied, follow-up in 2 weeks.','Sophia Martinez','Painkillers & Cast'),(7,'Allergy','Avoid known allergens.','Daniel Anderson','Cetirizine 10mg'),(8,'Cold & Cough','Rest and hydrate properly.','Olivia Thomas','Dextromethorphan Syrup'),(9,'Back Pain','Physical therapy recommended.','Liam Garcia','Muscle Relaxants'),(10,'Depression','Follow-up with therapist.','Isabella Rodriguez','Sertraline 50mg'),(11,'Ear Infection','Use prescribed ear drops.','Ethan Walker','Antibiotic Ear Drops'),(12,'High Cholesterol','Reduce fatty foods and exercise.','Mia Adams','Atorvastatin 10mg'),(13,'Arthritis','Joint pain observed, start mild exercise.','Noah Scott','Ibuprofen 200mg'),(14,'Food Poisoning','Hydrate and avoid solid food for 24 hours.','Ava Carter','ORS Solution'),(15,'Bronchitis','Coughing and chest pain reported.','Lucas Green','Prednisolone 10mg'),(16,'Stomach Ulcer','Avoid spicy food and caffeine.','Harper Baker','Omeprazole 20mg'),(17,'Sinusitis','Congestion and sinus pressure reported.','Evelyn Hall','Nasal Spray'),(18,'Pneumonia','Shortness of breath, needs antibiotics.','William Nelson','Azithromycin 500mg'),(19,'Anemia','Low hemoglobin, increase iron intake.','Benjamin Lewis','Ferrous Sulfate 325mg'),(20,'Skin Rash','Itchy and red patches on skin.','Charlotte Young','Hydrocortisone Cream'),(21,'Chickenpox','Mild fever and itchy blisters.','Henry Perez','Calamine Lotion'),(22,'Stroke Recovery','Needs physiotherapy sessions.','Ella Torres','Aspirin 81mg'),(23,'Gastroenteritis','Diarrhea and dehydration risk.','Jack Rivera','ORS and Probiotics'),(24,'Kidney Stones','Pain in lower back, increase fluid intake.','Luna Robinson','Painkillers & Hydration'),(25,'Thyroid Disorder','Monitor hormone levels.','Samuel Cooper','Levothyroxine 50mcg'),(26,'Tuberculosis','Chronic cough, needs further tests.','Grace Mitchell','Rifampin 600mg'),(27,'Vertigo','Dizziness, avoid sudden movements.','Alexander Carter','Meclizine 25mg'),(28,'Heart Disease','Chest pain on exertion.','Sofia Gonzalez','Nitroglycerin Sublingual'),(29,'Dengue Fever','High fever and body pain.','Daniel Reed','Fluid Therapy & Pain Relievers'),(30,'Appendicitis','Severe abdominal pain, urgent surgery needed.','Chloe Bennett','Surgical Consultation Required'),(31,'Flu','Patient has severe fever and cough.','Steve Roger','Paracetamol 500mg'),(32,'Acid Reflux','dont eat too fast','Al Francis','Algina');
/*!40000 ALTER TABLE `medical_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `morse_logs`
--

DROP TABLE IF EXISTS `morse_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `morse_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` enum('transmit','receive') NOT NULL,
  `code` varchar(255) NOT NULL,
  `translation` varchar(255) NOT NULL,
  `signal_strength` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=247 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `morse_logs`
--

LOCK TABLES `morse_logs` WRITE;
/*!40000 ALTER TABLE `morse_logs` DISABLE KEYS */;
INSERT INTO `morse_logs` VALUES (1,'transmit','... --- ...','NOOO',NULL,'2025-10-21 06:24:03'),(2,'receive','... ----..---|---.--','Safe here',20,'2025-10-21 06:25:42'),(3,'receive','... ----..---|---.--','Don\'t go ',50,'2025-10-21 06:57:58'),(4,'receive','... ----..---|---.--','Don\'t go ',50,'2025-10-21 06:58:23'),(5,'transmit','.|','E ',NULL,'2025-10-21 08:09:37'),(6,'transmit','.... ..|','HI ',NULL,'2025-10-21 08:12:07'),(7,'receive','..|','I ',-164,'2025-10-21 09:37:37'),(8,'receive','... ..|. ..|','SI EI ',-164,'2025-10-21 09:37:57'),(9,'receive','....|','H ',-164,'2025-10-21 09:40:09'),(10,'receive','........|',' ',-164,'2025-10-21 09:50:24'),(11,'transmit','..|','I ',NULL,'2025-10-21 10:01:26'),(12,'receive','...|','S ',-164,'2025-10-21 10:02:59'),(13,'transmit','...|','S ',NULL,'2025-10-21 10:13:24'),(14,'receive','....|','H ',-164,'2025-10-22 04:36:24'),(15,'receive','.|','E ',-164,'2025-10-22 04:39:33'),(16,'transmit','..|','I ',NULL,'2025-10-22 05:44:40'),(17,'transmit','... ..|','SI ',NULL,'2025-10-22 05:45:08'),(18,'receive','...|','S ',-164,'2025-10-22 05:46:34'),(19,'receive','.... .. ..|','HII ',-164,'2025-10-22 05:48:30'),(20,'transmit','-|','T ',NULL,'2025-10-22 05:48:46'),(21,'receive','.....|','5 ',-164,'2025-10-22 05:52:16'),(22,'receive','..|','I ',-164,'2025-10-22 09:54:03'),(23,'transmit','..|','I ',NULL,'2025-10-22 09:54:50'),(24,'transmit','...|','S ',NULL,'2025-10-22 09:54:57'),(25,'receive','....|','H ',-28,'2025-10-22 09:55:01'),(26,'receive','....|','H ',-164,'2025-10-23 07:22:06'),(27,'transmit','.... ..|','HI ',NULL,'2025-10-23 07:22:24'),(28,'transmit','.|','E ',NULL,'2025-10-24 00:43:15'),(29,'receive','.. ..|','II ',-164,'2025-10-24 00:47:09'),(30,'transmit','.... ..|','HI ',NULL,'2025-10-24 01:07:18'),(31,'transmit','.... ..|','HI ',NULL,'2025-10-24 01:24:25'),(32,'receive','.|.--. .- .-.. --..|','E PALZ ',-164,'2025-10-24 01:28:14'),(33,'receive','.--- .- .-.. --..|','JALZ ',-164,'2025-10-24 01:28:54'),(34,'receive','... .|... .- ..-. .|','SE SAFE ',-164,'2025-10-24 01:29:18'),(35,'receive','... . . ..-. .|','SEEFE ',-164,'2025-10-24 01:34:15'),(36,'transmit','... .- ..-. .|','SAFE ',NULL,'2025-10-24 01:34:22'),(37,'receive','.. ...|','IS ',-30,'2025-10-24 01:41:51'),(38,'transmit','.. .. . .|','IIEE ',NULL,'2025-10-24 01:42:30'),(39,'transmit','....|','H ',NULL,'2025-10-24 01:42:43'),(40,'receive','.... ..|','HI ',-24,'2025-10-24 01:42:59'),(41,'transmit','.|','E ',NULL,'2025-10-24 01:43:15'),(42,'transmit','.. ....|','IH ',NULL,'2025-10-24 01:43:31'),(43,'transmit','... ...|','SS ',NULL,'2025-10-24 01:43:56'),(44,'transmit','-|.|','T E ',NULL,'2025-10-24 01:44:30'),(45,'receive','.... ..|','HI ',-164,'2025-10-24 01:49:46'),(46,'transmit','. .|','EE ',NULL,'2025-10-24 01:52:43'),(47,'receive','.|','E ',-38,'2025-10-24 01:52:55'),(48,'receive','.... ..|','HI ',-164,'2025-10-24 02:08:13'),(49,'receive','.|','E ',-164,'2025-10-24 02:09:34'),(50,'receive','.- -.. -- . --. .--.|','ADMEGP ',-164,'2025-10-24 02:10:00'),(51,'receive','.- . - -.|- .-|','AETN TA ',-164,'2025-10-24 02:10:33'),(52,'receive','. -|...|','ET S ',-164,'2025-10-24 02:11:05'),(53,'transmit','...|','S ',NULL,'2025-10-24 02:11:22'),(54,'receive','..-|','U ',-18,'2025-10-24 02:11:34'),(55,'receive','. . .|','EEE ',-18,'2025-10-24 02:12:50'),(56,'receive','-|','T ',-18,'2025-10-24 02:13:16'),(57,'receive','-|..|','T I ',-18,'2025-10-24 02:13:39'),(58,'receive','. . .|- - -|. . .|','EEE TTT EEE ',-18,'2025-10-24 02:14:45'),(59,'transmit','.|','E ',NULL,'2025-10-24 02:17:27'),(60,'receive','.. -|','IT ',-10,'2025-10-24 02:17:34'),(61,'receive','.... ..|','HI ',-10,'2025-10-24 02:18:04'),(62,'receive','.... ..|','HI ',-164,'2025-10-24 02:20:36'),(63,'receive','..-.. .. ....|','IH ',-164,'2025-10-24 02:22:37'),(64,'receive','.... ..|.|','HI E ',-164,'2025-10-24 02:23:03'),(65,'receive','.... .. -.-.|','HIC ',-164,'2025-10-24 02:23:23'),(66,'receive','.... ..|- .- -.-|','HI TAK ',-164,'2025-10-24 02:24:06'),(67,'receive','....|','H ',-164,'2025-10-24 02:24:30'),(68,'transmit','.|','E ',NULL,'2025-10-24 02:26:02'),(69,'receive','...... ..|','I ',-95,'2025-10-24 02:28:02'),(70,'receive','..... ...|','5S ',-95,'2025-10-24 02:28:15'),(71,'receive','..... ..|... .. ...|','5I SIS ',-95,'2025-10-24 02:28:44'),(72,'receive','.... ..|','HI ',-95,'2025-10-24 02:29:12'),(73,'transmit','.....|','5 ',NULL,'2025-10-24 02:29:25'),(74,'receive','.|','E ',-19,'2025-10-24 02:34:41'),(75,'receive','......|',' ',-19,'2025-10-24 02:35:03'),(76,'receive','. .|','EE ',-19,'2025-10-24 02:36:34'),(77,'receive','...|','S ',-19,'2025-10-24 02:37:19'),(78,'receive','..|','I ',-19,'2025-10-24 02:37:29'),(79,'receive','... -|','ST ',-19,'2025-10-24 02:38:14'),(80,'receive','.... ..|','HI ',-19,'2025-10-24 02:38:42'),(81,'receive','.....|','5 ',-19,'2025-10-24 02:41:27'),(82,'receive','-.--..|',' ',-19,'2025-10-24 02:42:07'),(83,'transmit','..-|','U ',NULL,'2025-10-24 02:43:29'),(84,'transmit','..|..|','I I ',NULL,'2025-10-24 02:43:56'),(85,'transmit','..- ......|','U ',NULL,'2025-10-24 02:44:30'),(86,'transmit','.....|-.|','5 N ',NULL,'2025-10-24 02:45:08'),(87,'transmit','.- ...|','AS ',NULL,'2025-10-24 02:45:36'),(88,'receive','.- .. --.|','AIG ',-19,'2025-10-24 02:45:59'),(89,'receive','.... ..|... ..|','HI SI ',-98,'2025-10-24 02:46:28'),(90,'receive','... ..- ...|','SUS ',-98,'2025-10-24 02:47:16'),(91,'receive','.- ... ...|','ASS ',-98,'2025-10-24 02:47:43'),(92,'receive','... .. ..|','SII ',-98,'2025-10-24 02:48:09'),(93,'receive','--- -. ..|','ONI ',-98,'2025-10-24 02:48:31'),(94,'receive','.- .-- .--|','AWW ',-98,'2025-10-24 02:48:54'),(95,'receive','....-............|',' ',-98,'2025-10-24 02:49:26'),(96,'receive','.--...|',' ',-98,'2025-10-24 02:49:48'),(97,'receive','.- -...|','AB ',-98,'2025-10-24 02:50:04'),(98,'transmit','. -|','ET ',NULL,'2025-10-24 02:50:53'),(99,'transmit','...|','S ',NULL,'2025-10-24 02:51:03'),(100,'receive','...|','S ',-19,'2025-10-24 02:51:13'),(101,'receive','.... .. .|','HIE ',-19,'2025-10-24 02:51:32'),(102,'receive','.|. .|','E EE ',-19,'2025-10-24 02:51:56'),(103,'receive','-|','T ',-19,'2025-10-24 02:52:05'),(104,'receive','. .|','EE ',-19,'2025-10-24 02:52:15'),(105,'receive','. . .|','EEE ',-19,'2025-10-24 02:52:27'),(106,'receive','. .. .|','EIE ',-19,'2025-10-24 02:52:43'),(107,'transmit','- ..|','TI ',NULL,'2025-10-24 02:52:51'),(108,'receive','. . .|','EEE ',-21,'2025-10-24 02:52:59'),(109,'receive','- . .|- .. .|','TEE TIE ',-21,'2025-10-24 02:53:19'),(110,'receive','.|','E ',-21,'2025-10-24 02:53:46'),(111,'receive','.|','E ',-21,'2025-10-24 02:53:59'),(112,'receive','..|','I ',-21,'2025-10-24 02:54:17'),(113,'transmit','...|','S ',NULL,'2025-10-24 02:54:25'),(114,'receive','.|','E ',-18,'2025-10-24 02:54:26'),(115,'receive','...|','S ',-18,'2025-10-24 02:54:37'),(116,'receive','- . .|','TEE ',-18,'2025-10-24 02:54:52'),(117,'transmit','.|','E ',NULL,'2025-10-24 03:06:46'),(118,'receive','.-|','A ',-13,'2025-10-24 03:06:53'),(119,'receive','.- -.|','AN ',-13,'2025-10-24 03:07:35'),(120,'receive','.- -. .-..|....|','ANL H ',-13,'2025-10-24 03:08:12'),(121,'receive','... .-...|','S ',-13,'2025-10-24 03:09:12'),(122,'receive','...--...|',' ',-13,'2025-10-24 03:09:38'),(123,'receive','... .. ...|','SIS ',-13,'2025-10-24 03:10:13'),(124,'receive','.. .|','IE ',-13,'2025-10-24 03:11:54'),(125,'receive','...|','S ',-13,'2025-10-24 03:12:24'),(126,'receive','... ...- ...|','SVS ',-13,'2025-10-24 03:12:55'),(127,'receive','... ....|','SH ',-13,'2025-10-24 03:14:40'),(128,'receive','. ... . ..|','ESEI ',-13,'2025-10-24 03:15:13'),(129,'receive','.|','E ',-13,'2025-10-24 03:15:45'),(130,'receive','.---. -..|','D ',-13,'2025-10-24 03:16:22'),(131,'receive','. ... ...|','ESS ',-13,'2025-10-24 03:16:42'),(132,'receive','. -.-|','EK ',-13,'2025-10-24 03:17:01'),(133,'receive','...|','S ',-13,'2025-10-24 03:17:15'),(134,'receive','.-|. .-. . ..|','A EREI ',-13,'2025-10-24 03:17:42'),(135,'receive','.... ...|','HS ',-13,'2025-10-24 03:19:03'),(136,'receive','....... .. .. ..|','III ',-13,'2025-10-24 03:19:41'),(137,'receive','.-|.-..|','A L ',-13,'2025-10-24 03:22:13'),(138,'receive','.-|','A ',-13,'2025-10-24 03:29:02'),(139,'receive','.- -.|','AN ',-13,'2025-10-24 03:29:38'),(140,'receive','.--.. --.. --.|--. .- -. -.. .-|','ZG GANDA ',-13,'2025-10-24 03:30:43'),(141,'receive','-.-.|..- - .|','C UTE ',-13,'2025-10-24 03:31:24'),(142,'receive','-... .. .... ...-|','BIHV ',-13,'2025-10-24 03:32:14'),(143,'receive','...- ... ..|','VSI ',-13,'2025-10-24 03:32:46'),(144,'receive','-.- ---|-. --|.. -.-. ...... .....|','KO NM IC5 ',-13,'2025-10-24 03:34:19'),(145,'receive','-- --- .. ... ....|','MOISH ',-13,'2025-10-24 03:34:55'),(146,'receive','.-|','A ',-13,'2025-10-24 03:35:44'),(147,'receive','-..|','D ',-13,'2025-10-24 03:36:16'),(148,'receive','...|','S ',-13,'2025-10-24 03:36:29'),(149,'receive','..-|','U ',-13,'2025-10-24 03:36:44'),(150,'receive','---|','O ',-13,'2025-10-24 03:36:58'),(151,'receive','...|','S ',-13,'2025-10-24 03:37:08'),(152,'transmit','..|','I ',NULL,'2025-10-24 03:37:18'),(153,'receive','....|','H ',-11,'2025-10-24 03:38:00'),(154,'receive','....---....|',' ',-11,'2025-10-24 03:38:41'),(155,'receive','... --- ...|','SOS ',-11,'2025-10-24 03:39:08'),(156,'transmit','..|','I ',NULL,'2025-10-24 03:40:22'),(157,'transmit','.|','E ',NULL,'2025-10-24 03:40:35'),(158,'receive','--- - ...|','OTS ',-12,'2025-10-24 03:40:39'),(159,'receive','.- .....|','A5 ',-12,'2025-10-24 03:41:29'),(160,'transmit','...|','S ',NULL,'2025-10-24 03:41:39'),(161,'receive','.-.|---|...-|.|.-..|-.--|-.|','R O V E L Y N ',-20,'2025-10-24 03:42:37'),(162,'receive','.|','E ',-11,'2025-10-24 03:43:31'),(163,'transmit','.......... ....|','H ',NULL,'2025-10-24 03:43:44'),(164,'transmit','. ...|.... - ..|','ES HTI ',NULL,'2025-10-24 03:46:16'),(165,'receive','.|','E ',-30,'2025-10-24 03:47:40'),(166,'transmit','..|','I ',NULL,'2025-10-24 03:49:12'),(167,'receive','. ...-. .|','EE ',-47,'2025-10-24 03:49:36'),(168,'transmit','.... ............|','H ',NULL,'2025-10-24 03:49:47'),(169,'receive','.|..-|','E U ',-32,'2025-10-24 03:49:56'),(170,'receive','..-...|',' ',-32,'2025-10-24 03:52:56'),(171,'receive','.. ....-....|','I ',-32,'2025-10-24 03:54:38'),(172,'transmit','...|','S ',NULL,'2025-10-24 03:58:08'),(173,'transmit','.... .-|.|','HA E ',NULL,'2025-10-24 03:58:25'),(174,'receive','..|.- ..|','I AI ',-26,'2025-10-24 03:59:02'),(175,'receive','. .|. -|. .|','EE ET EE ',-26,'2025-10-24 03:59:50'),(176,'receive','. . . - - .|','EEETTE ',-26,'2025-10-24 04:00:29'),(177,'transmit','.. ..- .-.|','IUR ',NULL,'2025-10-24 04:01:04'),(178,'receive','.. .-|','IA ',-31,'2025-10-24 04:01:20'),(179,'receive','. . -. -.|','EENN ',-31,'2025-10-24 04:01:37'),(180,'receive','.. .- -.|','IAN ',-31,'2025-10-24 04:01:59'),(181,'transmit','......|',' ',NULL,'2025-10-24 04:02:46'),(182,'receive','-..|....|','D H ',-24,'2025-10-24 04:04:14'),(183,'receive','---|.-.. .. ....|','O LIH ',-95,'2025-10-24 04:04:50'),(184,'receive','.--|.-..|-|..|','W L T I ',-95,'2025-10-24 04:05:26'),(185,'receive','.--|.-..|- ..|','W L TI ',-95,'2025-10-24 04:05:58'),(186,'receive','.|.. .....|...|...|... ...... .. .|','E I5 S S SIE ',-95,'2025-10-24 04:06:49'),(187,'receive','.--- ..|','JI ',-95,'2025-10-24 04:07:53'),(188,'receive','-.|','N ',-95,'2025-10-24 04:08:08'),(189,'transmit','...|','S ',NULL,'2025-10-24 04:09:09'),(190,'receive','..... .. -- ..|','5IMI ',-13,'2025-10-24 04:09:22'),(191,'transmit','. ...|','ES ',NULL,'2025-10-24 04:09:29'),(192,'transmit','... ......|............. ......|','S  ',NULL,'2025-10-24 04:09:59'),(193,'receive','.--- .- -- ..|','JAMI ',-33,'2025-10-24 04:10:32'),(194,'receive','.|. .. ..|','E EII ',-33,'2025-10-24 04:12:14'),(195,'receive','.... ..|','HI ',-33,'2025-10-24 04:12:34'),(196,'receive','.................|',' ',-15,'2025-10-24 04:13:05'),(197,'transmit','.......|....|.......|',' H  ',NULL,'2025-10-24 04:13:20'),(198,'receive','.....|','5 ',-36,'2025-10-24 04:13:26'),(199,'receive','..|','I ',-17,'2025-10-24 04:13:37'),(200,'transmit','.--- .- .-.... .-.-.- ...-..|','JA ',NULL,'2025-10-24 04:13:57'),(201,'receive','.......|',' ',-16,'2025-10-24 04:14:16'),(202,'transmit','.--- .- -... --- .-...|','JABO ',NULL,'2025-10-24 04:14:39'),(203,'transmit','..- .- -. --. .-|','UANGA ',NULL,'2025-10-24 04:15:08'),(204,'receive','----.-|',' ',-31,'2025-10-24 04:15:34'),(205,'transmit','-.-|','K ',NULL,'2025-10-24 04:15:55'),(206,'receive','.... .. -...|','HIB ',-21,'2025-10-24 04:15:56'),(207,'transmit','- .|.|','TE E ',NULL,'2025-10-24 04:16:11'),(208,'receive','-.-. -.--|','CY ',-24,'2025-10-24 04:16:20'),(209,'transmit','-.. .-|','DA ',NULL,'2025-10-24 04:16:29'),(210,'transmit','- .- .|','TAE ',NULL,'2025-10-24 04:16:44'),(211,'receive','- .- -. --. .. -. .-|-- ---|','TANGINA MO ',-22,'2025-10-24 04:18:00'),(212,'transmit','.|','E ',NULL,'2025-10-24 04:22:41'),(213,'receive','.|','E ',-12,'2025-10-24 04:22:42'),(214,'transmit','..|','I ',NULL,'2025-10-24 04:25:14'),(215,'transmit','. ...|','ES ',NULL,'2025-10-24 04:25:43'),(216,'receive','.-|','A ',-22,'2025-10-24 04:25:48'),(217,'receive','.- -.|','AN ',-22,'2025-10-24 04:26:33'),(218,'receive','.- -.|-. .-|','AN NA ',-22,'2025-10-24 04:27:16'),(219,'transmit','..|..|','I I ',NULL,'2025-10-24 04:28:00'),(220,'receive','.. ..|....|','II H ',-26,'2025-10-24 04:28:12'),(221,'receive','-. -.|','NN ',-26,'2025-10-24 04:28:42'),(222,'receive','-- --|.---|','MM J ',-26,'2025-10-24 04:29:08'),(223,'receive','. .|.... .- .... ..|','EE HAHI ',-26,'2025-10-24 04:30:59'),(224,'receive','..........|',' ',-26,'2025-10-24 04:31:19'),(225,'receive','... .... ...|','SHS ',-26,'2025-10-24 04:31:37'),(226,'receive','....-|','4 ',-47,'2025-10-24 04:33:51'),(227,'transmit','.|','E ',NULL,'2025-10-24 04:33:56'),(228,'receive','.... ..|','HI ',-14,'2025-10-24 04:39:42'),(229,'receive','- .|','TE ',-14,'2025-10-24 04:40:43'),(230,'receive','. .. - .|','EITE ',-14,'2025-10-24 04:41:08'),(231,'receive','. .- -|','EAT ',-14,'2025-10-24 04:41:19'),(232,'receive','.-- .|','WE ',-14,'2025-10-24 04:41:46'),(233,'receive','- - -|','TTT ',-14,'2025-10-24 04:41:56'),(234,'receive','--.|','G ',-14,'2025-10-24 04:42:23'),(235,'receive','. .|','EE ',-14,'2025-10-24 04:42:34'),(236,'receive','..|','I ',-14,'2025-10-24 04:42:48'),(237,'receive','..-.-.|',' ',-14,'2025-10-24 04:43:03'),(238,'receive','.--. ---|.-.|..|','PO R I ',-14,'2025-10-24 04:43:30'),(239,'receive','.... ... ...|','HSS ',-14,'2025-10-24 04:44:02'),(240,'receive','.|','E ',-14,'2025-10-24 04:44:12'),(241,'receive','.--. --- --. ..|','POGI ',-14,'2025-10-24 04:44:37'),(242,'receive','.... .. ...|','HIS ',-14,'2025-10-24 04:45:00'),(243,'receive','.... .. ...|','HIS ',-14,'2025-10-24 04:45:24'),(244,'receive','-.-- .. ...|','YIS ',-14,'2025-10-24 04:45:41'),(245,'receive','.. ... ..|','ISI ',-14,'2025-10-24 04:46:10'),(246,'receive','.. ..- ..|..- ....|','IUI UH ',-14,'2025-10-24 04:46:38');
/*!40000 ALTER TABLE `morse_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-17 14:28:22
